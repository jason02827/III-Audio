//
//  ViewController.m
//  20170418HelloMyAVFoundation
//
//  Created by user35 on 2017/4/18.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()
{//全域變數
    AVAudioPlayer *musicPlayer;
    AVAudioRecorder *voiceRecorder; //錄音功能變數
    
    AVAudioPlayer *voicePlayer;
    NSURL *finalFullURL;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"Dora.mp3" withExtension:nil] ;   //主檔名 副檔名
//    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"Dora" withExtension:@"mp3"] ;
    musicPlayer = [[AVAudioPlayer alloc]initWithContentsOfURL:fileURL error:nil];
    musicPlayer.numberOfLoops = -1;  //重複播放次數  -1為無限
    musicPlayer.volume = 0.8; //音樂聲音音量，預設是1最大聲
    
    [musicPlayer prepareToPlay];   //播放前準備，直接play也是會在底層執行此功能，但不知道會花多少準備時間，若有兩種聲音可能會變成二部曲
    
    //Prepare Audio Session
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setCategory:AVAudioSessionCategoryPlayback error:nil];
    
    
    //取得使用者使用授權Ask user's permission of mic(取得麥克風需在此跟info增加授權)
    [session requestRecordPermission:^(BOOL granted) {
        //使用者首次使用 First time:true or false
        //第二次之後 Latter:==>true(依據首次的選擇)
        //第二次之後 Latter:==>false(依據首次的選擇)
        
        //Note! Here might be executed within background thread.
        //建議以下在實際專案中寫在主執行緒
        if (granted) {
            NSLog(@"User grant the permission");
        }else{
            NSLog(@"User don't grant the permission");
        }
    }];
    
    //錄音檔路徑與檔名Prepare Record File Path
    NSURL *documentsURL = [[NSFileManager defaultManager]URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject; //較新式路徑寫法，是陣列型態
//    NSURL *finalFullURL = [documentsURL URLByAppendingPathComponent:@"record.caf"];  //.caf是匹配kAudioFormatAppleIMA4
    finalFullURL = [documentsURL URLByAppendingPathComponent:@"record.caf"];
    NSLog(@"Record File:%@", finalFullURL);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)playMusicBtnPressed:(id)sender {
    
    if ([musicPlayer isPlaying]) {
        [musicPlayer pause];
    }else{
        [musicPlayer play];
    }
    
}
- (IBAction)recordVoiceBtnPressed:(id)sender {
    if ([voiceRecorder isRecording]) {
        [voiceRecorder stop];
        voiceRecorder = nil;  //此行是元件不用了就放掉
    }else{
        [self prepareRecording];
        [voiceRecorder record];
    }
    
}
- (IBAction)playVoiceBtnPressed:(id)sender {
    
    if ([voicePlayer isPlaying]) {
        [voicePlayer stop];
        voicePlayer = nil;
    }else{
        voicePlayer = [[AVAudioPlayer alloc]initWithContentsOfURL:finalFullURL error:nil];
        [voicePlayer prepareToPlay];
        [voicePlayer play];
    }
}

-(void) prepareRecording{ //準備錄音前準備
    NSDictionary *settings =
  @{AVFormatIDKey:@(kAudioFormatAppleIMA4), //編碼格式。@()內容是NSNumber
    AVSampleRateKey:@(22050.0), //錄音品質-22k,取樣頻率，波形，類比形
    AVNumberOfChannelsKey:@(1), //錄音品質-聲道，1是單聲道
    AVLinearPCMBitDepthKey:@(16), //錄音品質-用16bit來存
    AVLinearPCMIsBigEndianKey:@(false), //儲存方式是否為BigEndian,false是為配合mac,ios,windows
    AVLinearPCMIsFloatKey:@(false)}; //
    //一般光碟音樂品質為44100(44k),2(雙聲道),16bit
    //人聲8k or 16k,音樂演唱16k以上
    
   
    
    //Prepare voiceRecorder
    voiceRecorder = [[AVAudioRecorder alloc]initWithURL:finalFullURL settings:settings error:nil];
    [voiceRecorder prepareToRecord];
    //Prepare audio session
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    
    //meteringEnabled 呈現波形圖之類的
}


@end



